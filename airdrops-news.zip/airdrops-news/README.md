# Airdrops News

A Pen created on CodePen.io. Original URL: [https://codepen.io/Bassem-Zg/pen/BaXwdQv](https://codepen.io/Bassem-Zg/pen/BaXwdQv).

