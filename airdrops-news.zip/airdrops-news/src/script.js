// app.js
document.addEventListener('DOMContentLoaded', fetchAirdropNews);

function fetchAirdropNews() {
    const newsData = [
        {
            title: "توزيع جديد لـ TokenX",
            description: "احصل على حصتك من TokenX من خلال المشاركة في توزيع الإيردروب الأخير.",
            imgUrl: "https://via.placeholder.com/400x200",
        },
        {
            title: "توزيع CryptoY الآن متاح!",
            description: "سارع بالتسجيل الآن للحصول على حصة من إيردروب CryptoY لفترة محدودة.",
            imgUrl: "https://via.placeholder.com/400x200",
        },
        {
            title: "اربح مكافآت الإيردروب مع ProjectZ",
            description: "انضم إلى مجتمع ProjectZ واربح مكافآت الإيردروب.",
            imgUrl: "https://via.placeholder.com/400x200",
        }
    ];

    const newsContainer = document.getElementById('news-container');

    newsData.forEach(news => {
        const newsItem = document.createElement('div');
        newsItem.classList.add('news-item');

        newsItem.innerHTML = `
            <img src="${news.imgUrl}" alt="صورة الخبر">
            <h2>${news.title}</h2>
            <p>${news.description}</p>
        `;

        newsContainer.appendChild(newsItem);
    });
}
